package strategy;
/*
 * 收取现金
 */
public abstract class CashSuper {
	public abstract double acceptMoney(double money,double num);
}