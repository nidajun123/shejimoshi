package SimpleFactory;

public class Multiplication extends Operation{
	public double getValue(double number1,double number2){
		double value=0;
		value=number1*number2;
		return value;
	}
}
