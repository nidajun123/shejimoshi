package Decorator;

public class Sneakers extends Finery{
	public void show(){
		super.show();
		System.out.println("球鞋");
	}
}
